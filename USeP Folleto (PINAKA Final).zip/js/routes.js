angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('menu.home', {
    url: '/page1',
    views: {
      'side-menu21': {
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('menu.collegeOfArtsAndSciences', {
    url: '/cas',
    views: {
      'side-menu21': {
        templateUrl: 'templates/collegeOfArtsAndSciences.html',
        controller: 'collegeOfArtsAndSciencesCtrl'
      }
    }
  })

  .state('menu.collegeOfEducation', {
    url: '/ced',
    views: {
      'side-menu21': {
        templateUrl: 'templates/collegeOfEducation.html',
        controller: 'collegeOfEducationCtrl'
      }
    }
  })

  .state('menu.collegeOfEngineering', {
    url: '/coe',
    views: {
      'side-menu21': {
        templateUrl: 'templates/collegeOfEngineering.html',
        controller: 'collegeOfEngineeringCtrl'
      }
    }
  })

  .state('menu.collegeOfTechnology', {
    url: '/ct',
    views: {
      'side-menu21': {
        templateUrl: 'templates/collegeOfTechnology.html',
        controller: 'collegeOfTechnologyCtrl'
      }
    }
  })

  .state('menu.collegeOfGovernanceAndBusiness', {
    url: '/cgb',
    views: {
      'side-menu21': {
        templateUrl: 'templates/collegeOfGovernanceAndBusiness.html',
        controller: 'collegeOfGovernanceAndBusinessCtrl'
      }
    }
  })

  .state('menu.instituteOfComputing', {
    url: '/ic',
    views: {
      'side-menu21': {
        templateUrl: 'templates/instituteOfComputing.html',
        controller: 'instituteOfComputingCtrl'
      }
    }
  })

  .state('menu.schoolOfAppliedEconomics', {
    url: '/saec',
    views: {
      'side-menu21': {
        templateUrl: 'templates/schoolOfAppliedEconomics.html',
        controller: 'schoolOfAppliedEconomicsCtrl'
      }
    }
  })

  .state('menu.colleges', {
    url: '/page12',
    views: {
      'side-menu21': {
        templateUrl: 'templates/colleges.html',
        controller: 'collegesCtrl'
      }
    }
  })

  .state('menu.bSEconomics', {
    url: '/page13',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSEconomics.html',
        controller: 'bSEconomicsCtrl'
      }
    }
  })

  .state('menu.bSCommunityDevelopment', {
    url: '/page35',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSCommunityDevelopment.html',
        controller: 'bSCommunityDevelopmentCtrl'
      }
    }
  })

  .state('menu.bSEntrepreneurship', {
    url: '/page36',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSEntrepreneurship.html',
        controller: 'bSEntrepreneurshipCtrl'
      }
    }
  })

  .state('menu.bSPublicAdministration', {
    url: '/page37',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSPublicAdministration.html',
        controller: 'bSPublicAdministrationCtrl'
      }
    }
  })

  .state('bSEntrepreneurship2', {
    url: '/page17',
    templateUrl: 'templates/bSEntrepreneurship2.html',
    controller: 'bSEntrepreneurship2Ctrl'
  })

  .state('menu.bSInfromationTechnology', {
    url: '/page15',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSInfromationTechnology.html',
        controller: 'bSInfromationTechnologyCtrl'
      }
    }
  })

  .state('menu.bSComputerScience', {
    url: '/page16',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSComputerScience.html',
        controller: 'bSComputerScienceCtrl'
      }
    }
  })

  .state('menu.bSIndustrialTechnology', {
    url: '/page19',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSIndustrialTechnology.html',
        controller: 'bSIndustrialTechnologyCtrl'
      }
    }
  })

  .state('menu.bSComputerTechnology', {
    url: '/page38',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSComputerTechnology.html',
        controller: 'bSComputerTechnologyCtrl'
      }
    }
  })

  .state('menu.diplomaInTechnology', {
    url: '/page39',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diplomaInTechnology.html',
        controller: 'diplomaInTechnologyCtrl'
      }
    }
  })

  .state('bachelorOfTechnologyOfTeachingEducation', {
    url: '/page40',
    templateUrl: 'templates/bachelorOfTechnologyOfTeachingEducation.html',
    controller: 'bachelorOfTechnologyOfTeachingEducationCtrl'
  })

  .state('menu.bachelorInformationTechnology', {
    url: '/page41',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bachelorInformationTechnology.html',
        controller: 'bachelorInformationTechnologyCtrl'
      }
    }
  })

  .state('menu.bSCivilEngineering', {
    url: '/page21',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSCivilEngineering.html',
        controller: 'bSCivilEngineeringCtrl'
      }
    }
  })

  .state('menu.bSElectricalEngineering', {
    url: '/page22',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSElectricalEngineering.html',
        controller: 'bSElectricalEngineeringCtrl'
      }
    }
  })

  .state('menu.bSGeodeticEngineering', {
    url: '/page23',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSGeodeticEngineering.html',
        controller: 'bSGeodeticEngineeringCtrl'
      }
    }
  })

  .state('menu.bSMechanicalEngineering', {
    url: '/page24',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSMechanicalEngineering.html',
        controller: 'bSMechanicalEngineeringCtrl'
      }
    }
  })

  .state('menu.bSMiningEngineering', {
    url: '/page25',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSMiningEngineering.html',
        controller: 'bSMiningEngineeringCtrl'
      }
    }
  })

  .state('menu.bSElementaryEd', {
    url: '/page27',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSElementaryEd.html',
        controller: 'bSElementaryEdCtrl'
      }
    }
  })

  .state('menu.bSSecondaryEd', {
    url: '/page28',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSSecondaryEd.html',
        controller: 'bSSecondaryEdCtrl'
      }
    }
  })

  .state('menu.aBLanguage', {
    url: '/page30',
    views: {
      'side-menu21': {
        templateUrl: 'templates/aBLanguage.html',
        controller: 'aBLanguageCtrl'
      }
    }
  })

  .state('menu.aBLit', {
    url: '/page31',
    views: {
      'side-menu21': {
        templateUrl: 'templates/aBLit.html',
        controller: 'aBLitCtrl'
      }
    }
  })

  .state('menu.bSBiologicalScience', {
    url: '/page26',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSBiologicalScience.html',
        controller: 'bSBiologicalScienceCtrl'
      }
    }
  })

  .state('menu.bSMath', {
    url: '/page33',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSMath.html',
        controller: 'bSMathCtrl'
      }
    }
  })

  .state('menu.bSStat', {
    url: '/page34',
    views: {
      'side-menu21': {
        templateUrl: 'templates/bSStat.html',
        controller: 'bSStatCtrl'
      }
    }
  })

  .state('menu.developers', {
    url: '/page20',
    views: {
      'side-menu21': {
        templateUrl: 'templates/developers.html',
        controller: 'developersCtrl'
      }
    }
  })

  .state('menu.gallery', {
    url: '/page14',
    views: {
      'side-menu21': {
        templateUrl: 'templates/gallery.html',
        controller: 'galleryCtrl'
      }
    }
  })

  .state('menu.about', {
    url: '/page18',
    views: {
      'side-menu21': {
        templateUrl: 'templates/about.html',
        controller: 'aboutCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/side-menu21/page1')


});